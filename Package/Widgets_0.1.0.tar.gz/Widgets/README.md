# ShinyMeasures
This is a widget framework that makes nice capabilities for Reviewing measures in Shiny
